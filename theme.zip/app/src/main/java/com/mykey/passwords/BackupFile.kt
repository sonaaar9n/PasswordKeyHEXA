package com.mykey.passwords

import org.json.JSONArray
import org.json.JSONObject
import java.security.GeneralSecurityException
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/** PIN galat hai ya file kharab / badli hui hai. */
class BadPinOrFile : Exception("Galat PIN ya kharab file")

/** File .pkbackup nahi hai. */
class NotABackup : Exception("Ye PasswordKey ki .pkbackup file nahi hai")

/**
 * Encryption (Android ke built-in crypto se, koi library nahi):
 *   PIN  --PBKDF2-HMAC-SHA256 (random salt, 310,000 rounds)-->  256-bit key
 *   data --AES-256-GCM (random IV)-->  ciphertext + auth tag
 *
 * File layout:  "PKB1" (4 bytes) | salt (16) | iv (12) | ciphertext+tag
 * Galat PIN par GCM ka tag match nahi hota, isliye decrypt apne aap fail ho jata hai.
 */
object Crypto {
    private val MAGIC = byteArrayOf('P'.code.toByte(), 'K'.code.toByte(), 'B'.code.toByte(), '1'.code.toByte())
    private const val SALT_LEN = 16
    private const val IV_LEN = 12
    private const val TAG_BITS = 128
    private const val ROUNDS = 310_000

    private fun key(pin: String, salt: ByteArray): SecretKeySpec {
        val spec = PBEKeySpec(pin.toCharArray(), salt, ROUNDS, 256)
        val raw = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        spec.clearPassword()
        return SecretKeySpec(raw, "AES")
    }

    fun encrypt(plain: ByteArray, pin: String): ByteArray {
        val rnd = SecureRandom()
        val salt = ByteArray(SALT_LEN).also { rnd.nextBytes(it) }
        val iv = ByteArray(IV_LEN).also { rnd.nextBytes(it) }
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key(pin, salt), GCMParameterSpec(TAG_BITS, iv))
        c.updateAAD(MAGIC)
        return MAGIC + salt + iv + c.doFinal(plain)
    }

    fun decrypt(data: ByteArray, pin: String): ByteArray {
        val minLen = MAGIC.size + SALT_LEN + IV_LEN + TAG_BITS / 8
        if (data.size < minLen || !data.copyOfRange(0, MAGIC.size).contentEquals(MAGIC)) throw NotABackup()
        val salt = data.copyOfRange(4, 4 + SALT_LEN)
        val iv = data.copyOfRange(4 + SALT_LEN, 4 + SALT_LEN + IV_LEN)
        val body = data.copyOfRange(4 + SALT_LEN + IV_LEN, data.size)
        return try {
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, key(pin, salt), GCMParameterSpec(TAG_BITS, iv))
            c.updateAAD(MAGIC)
            c.doFinal(body)
        } catch (e: GeneralSecurityException) {
            throw BadPinOrFile()
        }
    }
}

/** Accounts <-> JSON <-> encrypted bytes. */
object BackupFile {

    class Decoded(val created: Long, val accounts: List<Account>)

    fun encode(accounts: List<Account>, pin: String): ByteArray {
        val arr = JSONArray()
        for (a in accounts) {
            arr.put(JSONObject().apply {
                put("id", a.id)
                put("platform", a.platform)
                put("label", a.label)
                put("username", a.username)
                put("usernameDate", a.usernameDate)
                put("cur", a.cur)
                put("curDate", a.curDate)
                put("p1", a.p1)
                put("p1Date", a.p1Date)
                put("p2", a.p2)
                put("p2Date", a.p2Date)
            })
        }
        val root = JSONObject().apply {
            put("v", 1)
            put("created", System.currentTimeMillis())
            put("accounts", arr)
        }
        return Crypto.encrypt(root.toString().toByteArray(Charsets.UTF_8), pin)
    }

    fun decode(data: ByteArray, pin: String): Decoded {
        val plain = Crypto.decrypt(data, pin)
        try {
            val root = JSONObject(String(plain, Charsets.UTF_8))
            val arr = root.getJSONArray("accounts")
            val list = ArrayList<Account>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    Account(
                        id = o.optLong("id"),
                        platform = o.optString("platform"),
                        label = o.optString("label"),
                        username = o.optString("username"),
                        usernameDate = o.optLong("usernameDate"),
                        cur = o.optString("cur"),
                        curDate = o.optLong("curDate"),
                        p1 = o.optString("p1"),
                        p1Date = o.optLong("p1Date"),
                        p2 = o.optString("p2"),
                        p2Date = o.optLong("p2Date")
                    )
                )
            }
            return Decoded(root.optLong("created"), list)
        } catch (e: org.json.JSONException) {
            throw BadPinOrFile()
        }
    }
}
