package com.mykey.passwords

/**
 * Import ka "date wala" merge. Android par nirbhar nahi hai, isliye alag se test ho sakta hai.
 *
 * Rules:
 *  - Backup ka koi password / username tabhi andar aata hai jab uski date app ke data se NAYI ho.
 *  - Backup ki date barabar ya purani ho to app ka data waisa hi rehta hai (kabhi replace nahi).
 *  - Password history: dono taraf ke (password, date) milake, sabse naye 3 rakhe jaate hain
 *    -> Current, Previous 1, Previous 2. Isse purana password kabhi "Current" nahi ban sakta.
 *  - Ek hi date par alag text ho (typo "Fix" ke baad) to app ka text jeetta hai.
 */
object Merge {

    class Result(val merged: Account, val fields: List<String>) {
        val changed get() = fields.isNotEmpty()
    }

    private data class Pw(val v: String, val d: Long)

    private fun sameEntry(a: Pw, b: Pw): Boolean =
        if (a.d == 0L || b.d == 0L) a.d == b.d && a.v == b.v else a.d == b.d

    fun merge(local: Account, inc: Account): Result {
        val fields = ArrayList<String>()

        // ---- Username / Email / Phone: sirf nayi date wala jeete ----
        var username = local.username
        var usernameDate = local.usernameDate
        if (inc.username.isNotEmpty() &&
            (local.username.isEmpty() || inc.usernameDate > local.usernameDate)
        ) {
            if (inc.username != local.username || inc.usernameDate != local.usernameDate) {
                username = inc.username
                usernameDate = inc.usernameDate
                fields.add("username")
            }
        }

        // ---- Passwords: dono ki history milao, sabse naye 3 rakho ----
        val localPw = listOf(Pw(local.cur, local.curDate), Pw(local.p1, local.p1Date), Pw(local.p2, local.p2Date))
            .filter { it.v.isNotEmpty() }
        val incPw = listOf(Pw(inc.cur, inc.curDate), Pw(inc.p1, inc.p1Date), Pw(inc.p2, inc.p2Date))
            .filter { it.v.isNotEmpty() }

        val all = ArrayList<Pw>(localPw)
        for (e in incPw) if (all.none { sameEntry(it, e) }) all.add(e)
        // stable sort: barabar date par app (local) wala pehle rehta hai
        val top = all.sortedByDescending { it.d }.take(3)

        fun at(i: Int) = top.getOrNull(i) ?: Pw("", 0L)
        val cur = at(0); val p1 = at(1); val p2 = at(2)

        if (cur.v != local.cur || cur.d != local.curDate) fields.add("password")
        if (p1.v != local.p1 || p1.d != local.p1Date || p2.v != local.p2 || p2.d != local.p2Date) {
            fields.add("old passwords")
        }

        // ---- Label: sirf tab badlo jab app me abhi default naam ("Instagram 1") ho ----
        var label = local.label
        val isDefault = Regex("^" + Regex.escape(local.platform) + " \\d+$").matches(local.label)
        if (isDefault && inc.label.isNotBlank() && inc.label != local.label) {
            label = inc.label
            fields.add("label")
        }

        val merged = local.copy(
            label = label,
            username = username, usernameDate = usernameDate,
            cur = cur.v, curDate = cur.d,
            p1 = p1.v, p1Date = p1.d,
            p2 = p2.v, p2Date = p2.d
        )
        return Result(merged, fields)
    }
}
